<template>
  <div class="supplement">
    <h3 class="title">
      <span class="fn">补充条款</span>
      <span class="fn">
        <icon class="el-icon-circle-plus"></icon>
        <icon class="el-icon-remove"></icon>
      </span>
    </h3>
    <el-row>
      <el-table border>
        <el-table-column label="序号"></el-table-column>
        <el-table-column label="条款"></el-table-column>
      </el-table>
    </el-row>
  </div>
</template>
<script>
export default {};
</script>
<style lang="scss">
</style>