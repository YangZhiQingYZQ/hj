<template>
  <div class="additional-exlain">
    <h3 class="title">附加说明</h3>
    <textarea name id cols="30" rows="10" class=  "area"></textarea>
  </div>
</template>
<script>
export default {};
</script>
<style lang="scss">
.area{
 width:100%;
}
</style>