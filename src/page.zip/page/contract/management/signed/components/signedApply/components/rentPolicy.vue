<template>
  <div class="rent-policy">
    <h3 class="title">租赁政策</h3>
    <el-table border>
      <el-table-column label="序号"></el-table-column>
      <el-table-column label="资源编号"></el-table-column>
      <el-table-column label="资源名称"></el-table-column>
      <el-table-column label="房源性质"></el-table-column>
      <el-table-column label="租赁面积"></el-table-column>
      <el-table-column label="业态"></el-table-column>
      <el-table-column label="时间起始"></el-table-column>
      <el-table-column label="时间截至"></el-table-column>
      <el-table-column label="标准价"></el-table-column>
      <el-table-column label="底价"></el-table-column>
      <el-table-column label="行业保证金"></el-table-column>
      <el-table-column label="履约保证金"></el-table-column>
      <el-table-column label="物管费"></el-table-column>
    </el-table>
  </div>
</template>
<script>
export default {};
</script>
<style>
</style>
